/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2018 NXP
 */

#ifndef _SNVS_SECURITY_SC_H
#define _SNVS_SECURITY_SC_H

int snvs_security_sc_init(void);

#endif /* _SNVS_SECURITY_SC_H */

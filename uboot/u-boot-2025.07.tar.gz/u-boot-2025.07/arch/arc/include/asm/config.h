/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2013-2014 Synopsys, Inc. All rights reserved.
 */

#ifndef __ASM_ARC_CONFIG_H_
#define __ASM_ARC_CONFIG_H_

#endif /*__ASM_ARC_CONFIG_H_ */
